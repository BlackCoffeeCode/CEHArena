const Razorpay = require('razorpay');
const admin = require('firebase-admin');

// Firebase Admin Initialize (Sirf 1 baar hoga)
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))
  });
}
const db = admin.firestore();

// Razorpay Initialize
const razorpay = new Razorpay({
  key_id: process.env.RZP_KEY_ID,
  key_secret: process.env.RZP_KEY_SECRET
});

// Netlify Serverless Function Handler
exports.handler = async (event) => {
  // CORS Headers (Firebase website se request aane ke liye)
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  // Browser preflight request handle karo
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Sirf POST requests allow karo
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const { paymentId, planKey, uid } = JSON.parse(event.body);

    if (!paymentId || !planKey || !uid) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing required fields' }) };
    }

    // 1️⃣ Razorpay se Payment Verify karo
    const payment = await razorpay.payments.fetch(paymentId);

    if (payment.status !== 'captured') {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Payment not captured' }) };
    }

    // 2️⃣ Plan Config (Prices daalo - Paise mein * 100)
    const planConfig = {
       starter:  { price: 34900, days: 30 }, // ₹349
       advanced: { price: 49900, days: 30 }, // ₹499
       ultimate: { price: 69900, days: 30 }  // ₹699
    };

    const plan = planConfig[planKey];
    if (!plan) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid plan key' }) };
    }

    // 3️⃣ Amount Match karo (Security Check 🔒)
    if (payment.amount !== plan.price) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Amount mismatch! Fraud detected.' }) };
    }

    // 4️⃣ Plan Activate karo Firebase mein
    const expiresAt = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() + plan.days * 24 * 60 * 60 * 1000)
    );

    await db.collection('users').doc(uid).update({
      plan: planKey,
      planExpiresAt: expiresAt,
      subscription_status: 'active',
      updated_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // 5️⃣ Payment Record save karo
    await db.collection('payments').add({
      user_id: uid,
      plan_key: planKey,
      amount: payment.amount / 100, // Paise se Rupees
      razorpay_payment_id: paymentId,
      status: 'verified',
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // ✅ Success Response
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, message: 'Plan activated successfully!' })
    };

  } catch (error) {
    console.error('Verification Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};